Kairah Studio — Cinematic Landing (Divine Motion)
-------------------------------------------------

Files in this package:
- index.html                : Full cinematic landing page (single-file).
- stripe_plans.json         : Placeholder JSON with your plan prices & IDs.
- ASSETS_PLACEHOLDER.txt    : Notes about adding background video and images.

How to preview:
1. Place a background video at: assets/teal_plum_mist.mp4
   - Recommended: 10-20s loop, 1280x720 or 1920x1080, H.264 baseline, target ~10-30MB for web testing.
2. Open index.html in a browser (double-click or serve via a static server).
3. For production, replace the Tailwind CDN with your build pipeline and integrate React components as needed.

Stripe / PayPal:
- stripe_plans.json contains the plan slugs and recommended prices.
- Replace plan IDs with your real Stripe Price IDs before wiring checkout.

Need help:
- I can push this to your GitHub (ai-pro-studio), add assets, and wire Stripe+PayPal checkout sessions on your backend.
- I can also convert this into React components and a Vercel deploy ready branch.

— Kairah Studio (assistant)
